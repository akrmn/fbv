--índices para la consulta 22

create index idx_q22_part on part (p_brand, p_type, p_size);
